# -*- coding:utf-8 -*-

import os
import datetime
import re


def createDir(path):
    dirName = str(datetime.datetime.today())[:10].replace('-','')
    command = 'mkdir -p %s' % (path + '/' + dirName)
    os.system(command) 
   
def filter_page(content,filter='点我达|美团|达达|外卖|骑手|跑单|派单|抢单|单子'):
    '''
    filter content of huasheng
    :param content: string content of huasheng
    :param filter: filter
    :return: if contain return true
    '''
    if content is None:
        return False
    m = re.search(re.compile(filter), content)
    if not m is None:
        return True
    else:
        return False


if __name__ == '__main__':
    with open("20181023124352487627.html","r") as rf:
        content=rf.read()
    print filter_page(content)