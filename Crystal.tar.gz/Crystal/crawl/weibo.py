# -*- coding:utf-8 -*-

import sys
sys.path.append('../')
import re
import datetime

from selenium import webdriver
from selenium.webdriver import ChromeOptions
from crawl.Crawl import crawl, getProxyIP
from config.Config import dataDir, chromeDir
from util.Common import createDir

def getLinks(IPs):
    url = 'http://s.weibo.com/weibo/点我达&Refer=index'
    chrome_options = ChromeOptions()
    #chrome_options.add_argument("start-maximized")
    chrome_options.add_argument('--headless')
    chrome_options.add_argument('--no-sandbox')
    driver = webdriver.Chrome(chromeDir, chrome_options=chrome_options)
    #print chromeDir
    #driver = webdriver.Chrome(chromeDir)
    driver.set_page_load_timeout(10)
    driver.get(url)
    page = driver.page_source
    page = page.encode('utf-8')
    driver.close()
    return page
    #page = crawl(url, IPs)
    #f = open('tmp.html', 'w')
    #page = page.encode('utf-8')
    #print >> f, page
    #f.close()

def saveMetaPage(page, pageid):
    #print page
    #page = page.encode('utf-8') #decode('gbk') #.encode('utf-8')
    #page = page.encode('utf-8') #decode('gbk') #.encode('utf-8')
    try:
        dirName = str(datetime.datetime.today())[:10].replace('-','')
        createDir(dataDir + '/weibo')
        f = open(dataDir + '/weibo/%s/%s.html' % (dirName, pageid), 'w')
        print >> f, page
        f.close()
    except Exception as e:
        print ("weibo saveMetaPage error !")

def getPages(links, IPs):
    for link in links:
        now = datetime.datetime.now()
        year = str(now.year)
        month = str(now.month) if now.month > 9 else '0' + str(now.month)
        day = str(now.day) if now.day > 9 else '0' + str(now.day)
        hour = str(now.hour) if now.hour > 9 else '0' + str(now.hour)
        minute = str(now.minute) if now.minute > 9 else '0' + str(now.minute)
        second = str(now.second) if now.second > 9 else '0' + str(now.second)
        microsecond = str(now.microsecond)
        for index in range(6-len(microsecond)):
            microsecond = '0' + microsecond
        pageid = year + month + day + hour + minute + second + microsecond
        #page = crawl(link, IPs)
        page = getLinks(IPs)
        saveMetaPage(page, pageid)

url = 'http://s.weibo.com/weibo/点我达&Refer=index'
IPs = getProxyIP()
getPages([url], IPs)
