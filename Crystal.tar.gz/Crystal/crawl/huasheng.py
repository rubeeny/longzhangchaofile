# -*- coding:utf-8 -*-

import sys
sys.path.append('..')
# sys.path.append('/home/Crystal/develop/Crystal')
import datetime
import re

from selenium import webdriver
from crawl.Crawl import crawl, getProxyIP
from config.Config import dataDir 
from util.Common import createDir, filter_page
from multiprocessing import Pool

def getLinks(IPs):
    url = 'https://ts.voc.com.cn/category/view/1/1.html'
    path = '/home/Crystal/develop/Crystal'
    #driver = webdriver.Chrome(path + '/thirdparty/chromedriver')
    #driver.get(url)
    #page = driver.page_source
    #driver.close()
    #f = open('tmp.html', 'w')
    #page = page.encode('utf-8')
    #print >> f, page
    #f.close()
    page = crawl(url, IPs)
    try:
        pageNum = re.search('<font color="blue">.*?</font>', page).group()
    except:
        pageNum = re.search('<font color=blue>.*?</font>', page).group()
    pageNum = re.search('[\d].*[\d]', pageNum).group()
    pageNum = int(pageNum)
    for index in range(2,100+1,1):
        url = 'https://ts.voc.com.cn/category/view/1/%d.html' % index
	#print index
	#driver.get(url)
	#page += driver.page_source
        page += crawl(url, IPs)
	#driver.close()
    #driver.quit()
    f = open('mainPage.html', 'w')
    print >> f, page
    f.close()

    links = []
    #bluelinks = re.findall('//ts.voc.com.cn/question/view/.*?.html', page) + re.findall('//ts.voc.com.cn/note/view/.*?.html', page) + re.findall('/question/view/.*?.html', page)
    bluelinks = re.findall('/question/view/.*?.html', page) #+ re.findall('/note/view/.*?.html', page)
    for bluelink in bluelinks:
        #if not bluelink.find('voc'):
        bluelink = '//ts.voc.com.cn' + bluelink 
        #print bluelink
        links.append('https:' + bluelink)
    if len(links)==0:
        print ("getLinks failed ,links is null")
    return links

def saveMetaPage(page, pageid):
    #print page
    #page = page.encode('utf-8') #decode('gbk') #.encode('utf-8')
    #page = page.encode('utf-8') #decode('gbk') #.encode('utf-8')
    try:
        dirName = str(datetime.datetime.today())[:10].replace('-','')
        createDir(dataDir + '/huasheng')
        f = open(dataDir + '/huasheng/%s/%s.html' % (dirName, pageid), 'w')
        print >> f, page
        f.close()
    except Exception as e:
        print (" huasheng save Metapage error")
        print (e.message)

def getPages(args):
    links, IPs = args
    for link in links:
        now = datetime.datetime.now()
        year = str(now.year)
        month = str(now.month) if now.month > 9 else '0' + str(now.month)
        day = str(now.day) if now.day > 9 else '0' + str(now.day)
        hour = str(now.hour) if now.hour > 9 else '0' + str(now.hour)
        minute = str(now.minute) if now.minute > 9 else '0' + str(now.minute)
        second = str(now.second) if now.second > 9 else '0' + str(now.second)
        microsecond = str(now.microsecond)
        for index in range(6-len(microsecond)):
            microsecond = '0' + microsecond
        pageid = year + month + day + hour + minute + second + microsecond
        page = crawl(link, IPs)
        page = link + '\n' + page
        #包含点我达相关类容，才保存
        if  filter_page(page):
            saveMetaPage(page, pageid)

IPs = getProxyIP()
links = getLinks(IPs)
args = [ [[link], IPs] for link in links ]
pool = Pool(4)
ansList = pool.map(getPages, args)

