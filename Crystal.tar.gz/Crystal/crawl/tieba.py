# -*- coding:utf-8 -*-
import sys
sys.path.append('..')

import re
import datetime
import logging

from selenium import webdriver
from selenium.webdriver import ChromeOptions
from crawl.Crawl import crawl, getProxyIP
from config.Config import dataDir, chromeDir
from util.Common import createDir
logger = logging.getLogger(__name__)

def getLinks():
    url = 'http://tieba.baidu.com/f/search/res?ie=utf-8&qw=点我达'
    chrome_options = ChromeOptions()
    chrome_options.add_argument('--headless')
    chrome_options.add_argument('--no-sandbox')
    chrome_options.add_argument('--disable-setuid-sandbox')
   
    print chromeDir
    driver = webdriver.Chrome(chromeDir, chrome_options=chrome_options)
    driver.get(url)
    page = driver.page_source

    links = []
    bluelinks = re.findall('<a data-tid.*? target=', page)
    for bluelink in bluelinks:
        link = re.search('href=".*?"', bluelink).group().replace('href=','').replace('"','')
        links.append('http://tieba.baidu.com' + link)
    if len(links)==0:
        logger.info("getLinks failed ,links is null")
        print ("getLinks failed ,links is null")
    return links

def getPageSource(url):
    chrome_options = ChromeOptions()
    chrome_options.add_argument('--headless')
    chrome_options.add_argument('--no-sandbox')
    driver = webdriver.Chrome(chromeDir, chrome_options=chrome_options)
    isSucc = False
    while not isSucc:
       try:
          driver.get(url)
          isSucc = True
       except:
          pass
    page = driver.page_source
    return page 

def saveMetaPage(page, pageid, link):
    #print page
    #page = page.encode('utf-8') #decode('gbk') #.encode('utf-8')
    #page = page.encode('utf-8') #decode('gbk') #.encode('utf-8')
    try:
        dirName = str(datetime.datetime.today())[:10].replace('-','')
        createDir(dataDir + '/tieba')
        f = open(dataDir + '/tieba/%s/%s.html' % (dirName, pageid), 'w')
        print >> f, link + '\n'
        print >> f, page
        f.close()
    except Exception as e:
        logger.info("saveMetaPage error !")
        print ("saveMetaPage error !")

def getPages(links, IPs):
    for link in links:
        #print link
        now = datetime.datetime.now()
        year = str(now.year)
        month = str(now.month) if now.month > 9 else '0' + str(now.month)
        day = str(now.day) if now.day > 9 else '0' + str(now.day) 
        hour = str(now.hour) if now.hour > 9 else '0' + str(now.hour)
        minute = str(now.minute) if now.minute > 9 else '0' + str(now.minute)
        second = str(now.second) if now.second > 9 else '0' + str(now.second)
        microsecond = str(now.microsecond)
        for index in range(6-len(microsecond)):
            microsecond = '0' + microsecond
        pageid = year + month + day + hour + minute + second + microsecond 
        page = crawl(link, IPs) 
        #page = getPageSource(link)
        pageNum = re.search('共<span class="red">.*?</span>页</li>', page).group()
        pageNum = re.search('\d+', pageNum).group()
        pageNum = int(pageNum)
        index = 2
        while index <= pageNum:
            page += crawl(link + '&pn=%d' % index, IPs)
            #page += getPageSource(link + '&pn=%d' % index)
            index+=1
        saveMetaPage(page, pageid, link)
   
links = getLinks()   
IPs = getProxyIP()
getPages(links, IPs)
