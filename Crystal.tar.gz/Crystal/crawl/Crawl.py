# -*- coding:utf-8 -*-
import httplib
import os
import sys
# sys.path.append('/home/Crystal/develop/Crystal')
import urllib2
import urllib
import  logging

from config.Config import dataDir, HEADER, USER_AGENTS
from random import choice
logger = logging.getLogger(__name__)

def getHeader():
    HEADER['User-Agent'] = choice(USER_AGENTS)
    return HEADER

def getProxyIP():
    fileDir = '../proxy/proxy_ip.csv'
    if not os.path.exists(fileDir):
        logger.info("getProxyIP error,"+fileDir+"is not exists!")
    f = open(fileDir, 'r')
    IPs = []
    for readLine in f:
       line = readLine.strip('\n')
       IPs.append(line)
    return IPs

def crawl(url, proxyIPs):
    try:
        proxyDict = {}
        proxy = { 'http' : choice(proxyIPs) }
        proxyDict['http'] = proxy
        header = getHeader()
        data = {'name' : 'Michael Foord', 'location' : 'Northampton'}

        proxy_handler = urllib2.ProxyHandler(proxy)
        opener = urllib2.build_opener(proxy_handler)
        opener.addheaders = header

        #request = urllib2.Request(url, data, header)
        # modify by longzhangchao

        response = urllib2.urlopen(url) #
        page = response.read()
        return page
    except   httplib.IncompleteRead as e:
        page = e.partial
        logger.info("read page error,or can not open"+url)
        return page


#url = 'http://tieba.baidu.com/f/search/res?ie=utf-8&qw=点我达'
#fileDir = '/home/Crystal/develop/Crystal/proxy/proxy_ip.csv'
#IPs = getProxyIP(fileDir)
#page = crawl(url, IPs)
#f = open('tmp.html', 'w')
#print >> f, page
#f.close()
