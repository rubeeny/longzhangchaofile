# -*- coding:utf-8 -*-

import sys
sys.path.append('/home/Crystal/develop/Crystal')

from config.Config import USER_AGENTS, HEADER, TIMEOUT
from random import choice
import threading
import re
import requests
import time

def getHeader():
    HEADER['User-Agent'] = choice(USER_AGENTS)
    return HEADER

def testIP(ip):
    proxy = { 'http': ip[0] + ':' + ip[1] }
    try_ip = ip[0]
    test_url = 'https://www.baidu.com'
    #print(try_ip)
    address = ip[0] + ':' + ip[1]
    #try:
    r = requests.get(test_url, headers=getHeader(), proxies=proxy, timeout=TIMEOUT)
    #except:
    #    print 'ip %s fail' % address
    #    return False
    #r = requests.get(test_url)
    if r.status_code == 200:
        r.encoding = 'gbk'
        result = re.search('\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}', r.text)
        print 'ip %s success' % address
        return True
    print 'ip %s fail 3' % address
    return False

def getScrawIPs(pageNum):
    scraw_url="http://www.xicidaili.com/nt/"
    scrawIPs = []
    #available_ip = []
    for page in range(1, pageNum, 1):
        url = scraw_url + str(page)
        r = requests.get(url, headers = getHeader())
        r.encoding = 'utf-8'
        pattern = re.compile('<td class="country">.*?alt="Cn" />.*?</td>.*?<td>(.*?)</td>.*?<td>(.*?)</td>', re.S)
        scrawIPs = scrawIPs + re.findall(pattern, r.text)
        #for ip in scraw_ip:
        #    if test_ip(ip) == True:
        #        available_ip.append(ip)
        #    else:
        #        pass
        time.sleep(2)
    return scrawIPs

def getAvailableIPs(scrawIPs):
    class multithreadTest(object):
        def __init__(self, scrawIPs):
            self.scrawIPs = scrawIPs
            self.availableIPs = []

        def pingIP(self, IPs):
            for IP in IPs:
                if not testIP(IP):
                    continue
                self.availableIPs.append(IP)

        def multiComputing(self):
            threadNum = min(len(self.scrawIPs),1000)
            threads = []
            if threadNum < 1:
                return self.availableIPs
            for index in range(0,len(self.scrawIPs),threadNum):
                threads.append( threading.Thread( self.pingIP(self.scrawIPs[index:index+threadNum]) ) )
            [ thread.start() for thread in threads ]
            [ thread.join() for thread in threads ]
            return self.availableIPs

    Test = multithreadTest(scrawIPs)
    availableIPs = Test.multiComputing()
    return availableIPs

def outputFile(availableIPs):
    path = '/home/Crystal/develop/Crystal/proxy/'
    f = open(path + 'proxy_ip.csv', 'w')
    for availableIP in availableIPs:
        proxy = str(availableIP[0]) + ':' + str(availableIP[1])
        print >> f, proxy
    f.close()

pageNum = 7
scrawIPs = getScrawIPs(pageNum)
availableIPs = getAvailableIPs(scrawIPs)
outputFile(availableIPs)
